import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression  # Logistic Regression import
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, precision_score, recall_score, f1_score, roc_curve
import matplotlib.pyplot as plt
from xgboost import plot_importance
import seaborn as sns
import matplotlib.pyplot as plt
import xgboost as xgb

# 데이터 불러오기
df_raw = pd.read_csv("./data/1주_실습데이터.csv")
df = df_raw.copy()

X = df.drop('Y', axis=1)  
Y = df['Y']

df.head()

#p.4
sns.countplot(data = df, x ="Y",hue="Y")

#p.5
# 설명변수 X1~X20
df.hist(figsize=(20, 15), bins=20, color='skyblue', edgecolor='black')

# 플롯을 표시
plt.tight_layout()

plt.show()

# 유의미하다고 생각되는 변수

#p.7
import pandas as pd

results = []
for column in df.columns:
    if column != 'Y':
        zero_count = (df[column] == 0).sum()
        zero_and_y_one_count = ((df[column] == 0) & (df['Y'] == 1)).sum()
        results.append([column, zero_count, zero_and_y_one_count])

results_df = pd.DataFrame(results, columns=['Column', 'Zero Count', 'Zero & Y=1 Count'])

# Display the resulting DataFrame
print(results_df)

#p.8
columns_to_check = ['X1', 'X2', 'X3', 'X4', 'X5', 'Y']
filtered_df = df[(df[columns_to_check[:-1]] == 0).any(axis=1) & (df['Y'] == 1)][columns_to_check]
print(filtered_df)

#---
columns_to_check = ['X3', 'X4', 'X5']
target_column = 'Y'

filtered_df = df[(df[columns_to_check] == 0).any(axis=1) & (df[target_column] == 1)][columns_to_check + [target_column]]

print(filtered_df)

#p.9
df['X4'].value_counts()

df['X13'].value_counts()

#p.10

# 상관관계 행렬 계산
corr_matrix = df.corr()

# 히트맵 그리기
plt.figure(figsize=(12, 10))

# 배경색 설정 및 글씨체 크기 조정
sns.set(font_scale=1.0)
sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap='coolwarm', center=0, linewidths=.5, 
            cbar_kws={"shrink": .8}, square=True)

# 제목 추가
plt.title('Correlation Matrix', fontsize=16)

# 히트맵 출력
plt.show()

# p.15
len(df["X9"].unique())

len(df["X14"].unique())


# p.16_A_1 baseline(RF)
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, precision_score,recall_score, f1_score, roc_curve
import matplotlib.pyplot as plt
from xgboost import plot_importance
import seaborn as sns

# 데이터 불러오기
df_raw = pd.read_csv("1주_실습데이터.csv")  
df = df_raw.copy()

sns.countplot(data = df, x ="Y",hue="Y")

X = df.drop('Y', axis=1)  
Y = df['Y']

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=42, stratify=Y)

# RandomForestClassifier 모델 학습(그냥)
rf_model = RandomForestClassifier(random_state=42)
rf_model.fit(X_train, Y_train)

#예측값
Y_pred_proba_origin = rf_model.predict_proba(X_test)[:, 1]  # 클래스 1의 확률값을 가져옵니다.
Y_pred_origin = rf_model.predict(X_test)  # 예측 레이블

# SMOTE 적용
smote = SMOTE(random_state=42)
X_train_resampled, Y_train_resampled = smote.fit_resample(X_train, Y_train)

# RandomForestClassifier 모델 학습(오버샘플링)
rf_model_over = RandomForestClassifier(random_state=42)
rf_model_over.fit(X_train_resampled, Y_train_resampled)

#예측값
Y_pred_proba_over = rf_model_over.predict_proba(X_test)[:, 1]  # 확률값만
Y_pred_over = rf_model_over.predict(X_test)  # 예측 레이블

# precision 계산
precision_origin= precision_score(Y_test, Y_pred_origin)
precision_over = precision_score(Y_test, Y_pred_over)
print(f'precision origin: {precision_origin:.8f}')
print(f'precision over: {precision_over:.8f}')

# recall 계산
recall_origin = recall_score(Y_test, Y_pred_origin) 
recall_over = recall_score(Y_test, Y_pred_over)
print(f'recall origin: {recall_origin:.8f}')
print(f'recall over: {recall_over:.8f}')

# F1 Score 계산
f1_origin = f1_score(Y_test, Y_pred_origin, average='binary')
f1_over = f1_score(Y_test, Y_pred_over, average='binary')
print(f'F1 Score origin: {f1_origin:.8f}')
print(f'F1 Score over: {f1_over:.8f}')

# ROC-AUC 계산
roc_auc_origin = roc_auc_score(Y_test, Y_pred_proba_origin)
roc_auc_over = roc_auc_score(Y_test, Y_pred_proba_over)
print(f'ROC-AUC origin: {roc_auc_origin:.8f}')
print(f'ROC-AUC over: {roc_auc_over:.8f}')

'''precision origin: 1.00000000
precision over: 0.99982421
recall origin: 0.99707602
recall over: 0.99783626
F1 Score origin: 0.99853587
F1 Score over: 0.99882925
ROC-AUC origin: 0.99984855
ROC-AUC over: 0.99996322'''

# p.16_A_2 xg boosting 
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, precision_score, f1_score, recall_score
import matplotlib.pyplot as plt
import xgboost as xgb

# 데이터 불러오기
df_raw = pd.read_csv("1주_실습데이터.csv")
df = df_raw.copy()

X = df.drop(['Y',"X4","X7","X13","X16","X17"], axis=1)  
Y = df['Y']


X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=42, stratify=Y)

# XGBoost 분류기 학습(그냥)
model = xgb.XGBClassifier(random_state=42)

model.fit(X_train, Y_train)
#예측값
Y_pred_proba_origin = model.predict_proba(X_test)[:, 1]  # 확률값만
Y_pred_origin = model.predict(X_test)  # 예측 레이블

# SMOTE 적용
smote = SMOTE(random_state=42)
X_train_resampled, Y_train_resampled = smote.fit_resample(X_train, Y_train)

# XGBoost 분류기 학습(오버샘플링)
model_over = xgb.XGBClassifier(random_state=42)

model_over.fit(X_train_resampled, Y_train_resampled)

#예측값
Y_pred_proba_over = model_over.predict_proba(X_test)[:, 1]  #확률값만
Y_pred_over = model_over.predict(X_test)  # 예측 레이블

# precision 계산
precision_origin= precision_score(Y_test, Y_pred_origin) 
precision_over = precision_score(Y_test, Y_pred_over)
print(f'precision origin: {precision_origin:.8f}')
print(f'precision over: {precision_over:.8f}')

# recall 계산
recall_origin = recall_score(Y_test, Y_pred_origin) 
recall_over = recall_score(Y_test, Y_pred_over)
print(f'recall origin: {recall_origin:.8f}')
print(f'recall over: {recall_over:.8f}')

# F1 Score 계산
f1_origin = f1_score(Y_test, Y_pred_origin, average='binary')
f1_over = f1_score(Y_test, Y_pred_over, average='binary')
print(f'F1 Score origin: {f1_origin:.8f}')
print(f'F1 Score over: {f1_over:.8f}')

# ROC-AUC 계산
roc_auc_origin = roc_auc_score(Y_test, Y_pred_proba_origin)
roc_auc_over = roc_auc_score(Y_test, Y_pred_proba_over)
print(f'ROC-AUC origin: {roc_auc_origin:.8f}')
print(f'ROC-AUC over: {roc_auc_over:.8f}')



""" Xg boost
precision origin: 0.99988274
precision over: 0.99947288
recall origin: 0.99730994
recall over: 0.99795322
F1 Score origin: 0.99859468
F1 Score over: 0.99871247
ROC-AUC origin: 0.99986042
ROC-AUC over: 0.99991411
"""
# p.16_A_3 logistic 
import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression  # Logistic Regression import
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, precision_score, recall_score, f1_score, roc_curve
import matplotlib.pyplot as plt
from xgboost import plot_importance

# 데이터 불러오기
df_raw = pd.read_csv("1주_실습데이터.csv")
df = df_raw.copy()

X = df.drop('Y', axis=1)  
Y = df['Y']

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=42, stratify=Y)

# Logistic Regression 모델 학습(그냥)
logreg_model = LogisticRegression(random_state=42, max_iter=1000)
logreg_model.fit(X_train, Y_train)

# 예측값
Y_pred_proba_origin = logreg_model.predict_proba(X_test)[:, 1]  # 확률값만
Y_pred_origin = logreg_model.predict(X_test)  # 예측 레이블

# SMOTE 적용
smote = SMOTE(random_state=42)
X_train_resampled, Y_train_resampled = smote.fit_resample(X_train, Y_train)

# Logistic Regression 모델 학습(오버샘플링)
logreg_model_over = LogisticRegression(random_state=42, max_iter=1000)
logreg_model_over.fit(X_train_resampled, Y_train_resampled)

# 예측값
Y_pred_proba_over = logreg_model_over.predict_proba(X_test)[:, 1]  #확률값만
Y_pred_over = logreg_model_over.predict(X_test)  # 예측 레이블

# precision 계산
precision_origin = precision_score(Y_test, Y_pred_origin)
precision_over = precision_score(Y_test, Y_pred_over)
print(f'precision origin: {precision_origin:.8f}')
print(f'precision over: {precision_over:.8f}')

# recall 계산
recall_origin = recall_score(Y_test, Y_pred_origin)
recall_over = recall_score(Y_test, Y_pred_over)
print(f'recall origin: {recall_origin:.8f}')
print(f'recall over: {recall_over:.8f}')

# F1 Score 계산
f1_origin = f1_score(Y_test, Y_pred_origin, average='binary')
f1_over = f1_score(Y_test, Y_pred_over, average='binary')
print(f'F1 Score origin: {f1_origin:.8f}')
print(f'F1 Score over: {f1_over:.8f}')

# ROC-AUC 계산
roc_auc_origin = roc_auc_score(Y_test, Y_pred_proba_origin)
roc_auc_over = roc_auc_score(Y_test, Y_pred_proba_over)
print(f'ROC-AUC origin: {roc_auc_origin:.8f}')
print(f'ROC-AUC over: {roc_auc_over:.8f}')

"Logistic"
# precision origin: 0.99774876
# precision over: 0.97200872
# recall origin: 0.90713450
# recall over: 0.99099415
# F1 Score origin: 0.95028640
# F1 Score over: 0.98140963
# ROC-AUC origin: 0.99753201
# ROC-AUC over: 0.99782668

# p.16_A_4 lgbm
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from lightgbm import LGBMClassifier
from sklearn.metrics import roc_auc_score,recall_score, precision_score, f1_score, roc_curve
import matplotlib.pyplot as plt

# 데이터 불러오기
df_raw = pd.read_csv("1주_실습데이터.csv")
df = df_raw.copy()

X = df.drop('Y', axis=1)  
Y = df['Y']

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=42, stratify=Y)

# LGBM_Classifier
lb_model = LGBMClassifier(random_state=42)
lb_model.fit(X_train,Y_train)

#예측값
Y_pred_proba_origin = lb_model.predict_proba(X_test)[:, 1]  # 확률값만
Y_pred_origin = lb_model.predict(X_test)  # 예측 레이블

# SMOTE 적용
smote = SMOTE(random_state=42)
X_train_resampled, Y_train_resampled = smote.fit_resample(X_train, Y_train)

# LGBM_Classifier(오버샘플링)
lb_model_over = LGBMClassifier(random_state=42)
lb_model_over.fit(X_train_resampled,Y_train_resampled)

#예측값
Y_pred_proba_over = lb_model_over.predict_proba(X_test)[:, 1]  # 확률값만
Y_pred_over = lb_model_over.predict(X_test)  # 예측 레이블

# precision 계산
precision_origin= precision_score(Y_test, Y_pred_origin) 
precision_over = precision_score(Y_test, Y_pred_over)
print(f'precision origin: {precision_origin:.8f}')
print(f'precision over: {precision_over:.8f}')

# recall 계산
recall_origin = recall_score(Y_test, Y_pred_origin)
recall_over = recall_score(Y_test, Y_pred_over)
print(f'recall origin: {recall_origin:.8f}')
print(f'recall over: {recall_over:.8f}')

# F1 Score 계산
f1_origin = f1_score(Y_test, Y_pred_origin, average='binary')
f1_over = f1_score(Y_test, Y_pred_over, average='binary')
print(f'F1 Score origin: {f1_origin:.8f}')
print(f'F1 Score over: {f1_over:.8f}')

# ROC-AUC 계산
roc_auc_origin = roc_auc_score(Y_test, Y_pred_proba_origin)
roc_auc_over = roc_auc_score(Y_test, Y_pred_proba_over)
print(f'ROC-AUC origin: {roc_auc_origin:.8f}')
print(f'ROC-AUC over: {roc_auc_over:.8f}')

""" LGBM 
precision origin: 0.99585135
precision over: 0.99859518

recall origin: 0.99666667
recall over: 0.99766082

F1 Score origin: 0.99625884
F1 Score over: 0.99812778

ROC-AUC origin: 0.99914822
ROC-AUC over: 0.99984999
"""
# p.16_B (RF,Xgboost,칼럼 제거)
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, precision_score, f1_score, recall_score
import matplotlib.pyplot as plt
import xgboost as xgb

# 데이터 불러오기
df_raw = pd.read_csv("1주_실습데이터.csv")
df = df_raw.copy()

X = df.drop(['Y',"X4","X7","X13","X16","X17"], axis=1)  
Y = df['Y']

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=42, stratify=Y)

# SMOTE 적용(오버샘플링!)
smote = SMOTE(random_state=42)
X_train_resampled, Y_train_resampled = smote.fit_resample(X_train, Y_train)

# rf 분류 모델 학습
rf_model = RandomForestClassifier(random_state=42)
rf_model.fit(X_train_resampled, Y_train_resampled)

#예측값
Y_pred_proba_rf = rf_model.predict_proba(X_test)[:, 1]  # 확률값만
Y_pred_rf = rf_model.predict(X_test)  # 예측 레이블

# XGBoost 학습
xgb_model = xgb.XGBClassifier(random_state=42)
xgb_model.fit(X_train_resampled, Y_train_resampled)

#값 예측
Y_pred_proba_xgb = xgb_model.predict_proba(X_test)[:, 1] 
Y_pred_xgb = xgb_model.predict(X_test)  

# precision 계산
precision_rf= precision_score(Y_test, Y_pred_rf)
precision_xgb = precision_score(Y_test, Y_pred_xgb)
print(f'precision rf: {precision_rf:.8f}')
print(f'precision xgb: {precision_xgb:.8f}')

# recall 계산
recall_rf = recall_score(Y_test, Y_pred_rf)
recall_xgb = recall_score(Y_test, Y_pred_xgb)
print(f'recall rf: {recall_rf:.8f}')
print(f'recall xgb: {recall_xgb:.8f}')

# F1 Score 계산
f1_rf = f1_score(Y_test, Y_pred_rf, average='binary')
f1_xgb = f1_score(Y_test, Y_pred_xgb, average='binary')
print(f'F1 Score rf: {f1_rf:.8f}')
print(f'F1 Score xgb: {f1_xgb:.8f}')

# ROC-AUC 계산
roc_auc_rf = roc_auc_score(Y_test, Y_pred_proba_rf)
roc_auc_xgb = roc_auc_score(Y_test, Y_pred_proba_xgb)
print(f'ROC-AUC rf: {roc_auc_rf:.8f}')
print(f'ROC-AUC xgb: {roc_auc_xgb:.8f}')

"""
precision rf: 0.99976564
precision xgb: 0.99935586
recall rf: 0.99789474
recall xgb: 0.99801170
F1 Score rf: 0.99882931
F1 Score xgb: 0.99868333
ROC-AUC rf: 0.99999305
ROC-AUC xgb: 0.99982405
"""
# p.16_C(RF,Xgboost,칼럼제거,”X5”변환)
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, precision_score, f1_score, recall_score
import matplotlib.pyplot as plt
import xgboost as xgb
import seaborn as sns
from xgboost import plot_importance

# 데이터 불러오기
df_raw = pd.read_csv("1주_실습데이터.csv")
df = df_raw.copy()

cut_lim = [-0.1,0.0,0.2,0.45,0.6,1.1]
labels = [0.0,0.25,0.5,0.75,1.0]

df["X5_cut"] = pd.cut(df["X5"],bins=cut_lim,labels=labels)
df['X5_cut'] = df['X5_cut'].astype(float)
X = df.drop(['Y',"X4","X7","X13","X16","X17","X5"], axis=1)  
Y = df['Y']  

X_train, X_test, Y_train, Y_test = train_test_split(X, Y,\
                                test_size=0.3, random_state=42, stratify=Y)

# SMOTE 적용(오버샘플링!)

smote = SMOTE(random_state=42)
X_train_resampled, Y_train_resampled = smote.fit_resample(X_train, Y_train)

# rf 분류 모델 학습
rf_model = RandomForestClassifier(random_state=42)
rf_model.fit(X_train_resampled, Y_train_resampled)

#예측값
Y_pred_proba_rf = rf_model.predict_proba(X_test)[:, 1]  #확률값만
Y_pred_rf = rf_model.predict(X_test)  # 예측 레이블

# XGBoost 학습
xgb_model = xgb.XGBClassifier(random_state=42)
xgb_model.fit(X_train_resampled, Y_train_resampled)

#값 예측
Y_pred_proba_xgb = xgb_model.predict_proba(X_test)[:, 1] 
Y_pred_xgb = xgb_model.predict(X_test)  

# precision 계산
precision_rf= precision_score(Y_test, Y_pred_rf)
precision_xgb = precision_score(Y_test, Y_pred_xgb)
print(f'precision rf: {precision_rf:.8f}')
print(f'precision xgb: {precision_xgb:.8f}')

# recall 계산
recall_rf = recall_score(Y_test, Y_pred_rf)
recall_xgb = recall_score(Y_test, Y_pred_xgb)
print(f'recall rf: {recall_rf:.8f}')
print(f'recall xgb: {recall_xgb:.8f}')

# F1 Score 계산
f1_rf = f1_score(Y_test, Y_pred_rf, average='binary')
f1_xgb = f1_score(Y_test, Y_pred_xgb, average='binary')
print(f'F1 Score rf: {f1_rf:.8f}')
print(f'F1 Score xgb: {f1_xgb:.8f}')

# ROC-AUC 계산
roc_auc_rf = roc_auc_score(Y_test, Y_pred_proba_rf)
roc_auc_xgb = roc_auc_score(Y_test, Y_pred_proba_xgb)
print(f'ROC-AUC rf: {roc_auc_rf:.8f}')
print(f'ROC-AUC xgb: {roc_auc_xgb:.8f}')

"""
precision rf: 0.99970714
precision xgb: 0.99953145
recall rf: 0.99812865
recall xgb: 0.99801170
F1 Score rf: 0.99891727
F1 Score xgb: 0.99877100
ROC-AUC rf: 0.99999607
ROC-AUC xgb: 0.99986181"""

# p.16_D(RF,Xgboost,칼럼제거,’X5’열 변환,파생 변수)
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, precision_score, f1_score, recall_score
import matplotlib.pyplot as plt
import xgboost as xgb

# 데이터 불러오기
df_raw = pd.read_csv("1주_실습데이터.csv")
df = df_raw.copy()

df["X5"].hist()
cut_lim = [-1,0,0.2,0.45,0.6,df["X5"].max()]

labels = [0,0.25,0.5,0.75,1]

## y와 상관계수가 높은 변수와 해당 변수와의 상관계수가 작은 변수를 곱해 파생변수 추가
df['X3_12'] = df['X3']* df['X12']
df['X3_15'] = df['X3']* df['X15']
df['X3_19'] = df['X3']* df['X19']
df['X5_19'] = df['X5']* df['X1']
df['X5_19'] = df['X5']* df['X10']

df["X5_cut"] = pd.cut(df["X5"],bins=cut_lim,labels=labels)
df['X5_cut'] = df['X5_cut'].astype(float)
X = df.drop(['Y',"X4","X7","X13","X16","X17","X5"], axis=1)  
Y = df['Y']  

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=42, stratify=Y)

# SMOTE 적용(오버샘플링!)
smote = SMOTE(random_state=42)
X_train_resampled, Y_train_resampled = smote.fit_resample(X_train, Y_train)

# rf 분류 모델 학습
rf_model = RandomForestClassifier(random_state=42)
rf_model.fit(X_train_resampled, Y_train_resampled)

#예측값
Y_pred_proba_rf = rf_model.predict_proba(X_test)[:, 1]  # 확률값만
Y_pred_rf = rf_model.predict(X_test)  # 예측 레이블

# XGBoost 학습
xgb_model = xgb.XGBClassifier()
xgb_model.fit(X_train_resampled, Y_train_resampled)

#값 예측
Y_pred_proba_xgb = xgb_model.predict_proba(X_test)[:, 1] 
Y_pred_xgb = xgb_model.predict(X_test)  

# precision 계산
precision_rf= precision_score(Y_test, Y_pred_rf)
precision_xgb = precision_score(Y_test, Y_pred_xgb)
print(f'precision rf: {precision_rf:.8f}')
print(f'precision xgb: {precision_xgb:.8f}')

# recall 계산
recall_rf = recall_score(Y_test, Y_pred_rf)
recall_xgb = recall_score(Y_test, Y_pred_xgb)
print(f'recall rf: {recall_rf:.8f}')
print(f'recall xgb: {recall_xgb:.8f}')

# F1 Score 계산
f1_rf = f1_score(Y_test, Y_pred_rf, average='binary')
f1_xgb = f1_score(Y_test, Y_pred_xgb, average='binary')
print(f'F1 Score rf: {f1_rf:.8f}')
print(f'F1 Score xgb: {f1_xgb:.8f}')

# ROC-AUC 계산
roc_auc_rf = roc_auc_score(Y_test, Y_pred_proba_rf)
roc_auc_xgb = roc_auc_score(Y_test, Y_pred_proba_xgb)
print(f'ROC-AUC rf: {roc_auc_rf:.8f}')
print(f'ROC-AUC xgb: {roc_auc_xgb:.8f}')

"""
precision rf: 0.99964822
precision xgb: 0.99929734
recall rf: 0.99707602
recall xgb: 0.99801170
F1 Score rf: 0.99836046
F1 Score xgb: 0.99865410
ROC-AUC rf: 0.99989522
ROC-AUC xgb: 0.99979273
"""

#p.17
### 그래프 1
# 변수 중요도 가져오기 
importances = rf_model.feature_importances_

# 변수 이름과 함께 데이터 정리
feature_names = X_train.columns  # 훈련 데이터의 열 이름
importance_df = pd.DataFrame({
    'Features': feature_names,
    'Importance': importances
})

# 중요도를 기준으로 내림차순 정렬
importance_df = importance_df.sort_values(by='Importance', ascending=False)

# 그래프 그리기
plt.figure(figsize=(10, 6))
plt.barh(importance_df['Features'], importance_df['Importance'], color='b')
plt.xlabel('Importance')
plt.ylabel('Features')
plt.title('Feature Importance (Random Forest)')
plt.gca().invert_yaxis()  # 상위 중요도가 위에 오도록 축을 반전
plt.show()

### 그래프 2

import shap
from sklearn.ensemble import RandomForestClassifier
import matplotlib.pyplot as plt

explainer = shap.TreeExplainer(rf_model)
shap_values = explainer.shap_values(X_test)

#:,:,1 로 해서 차원 맞춰야함
shap.summary_plot(shap_values[:,:,1], X_test, plot_type="bar")  # For class 1




#p.18
from sklearn.metrics import confusion_matrix
conf_mat1 = confusion_matrix(y_true=Y_test, y_pred=Y_pred_rf)

from sklearn.metrics import ConfusionMatrixDisplay
p = ConfusionMatrixDisplay(confusion_matrix = conf_mat1)
p.plot(cmap="Blues")


df2 = df_raw.copy()

df_0 = df2.query("Y == 0")
df_1 = df2.query("Y == 1")
# X8
plt.figure(figsize=(8, 6))
plt.boxplot([df_0['X8'], df_1['X8']], labels=['Y = 0', 'Y = 1'], showfliers=False)
plt.ylim(0, 0.1)  # Y축 범위 설정
plt.title('Boxplot of X8 by Y')
plt.ylabel('Values')
plt.xlabel('Y')
plt.show()

# X11
plt.figure(figsize=(8, 6))
plt.boxplot([df_0['X11'], df_1['X11']], labels=['Y = 0', 'Y = 1'], showfliers=True)
plt.ylim(0, 0.02)  # Y축 범위 설정
plt.title('Boxplot of X11 by Y')
plt.ylabel('Values')
plt.xlabel('Y')
plt.show()

# X18
plt.figure(figsize=(8, 6))
plt.boxplot([df_0['X18'], df_1['X18']], labels=['Y = 0', 'Y = 1'], showfliers=False)
plt.ylim(0, 0.1)  # Y축 범위 설정
plt.title('Boxplot of X18 by Y')
plt.ylabel('Values')
plt.xlabel('Y')
plt.show()